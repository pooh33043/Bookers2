# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '42f283bd2f009663a355df7221fffb8ca390766da61b62134629fd9e698489a7991234f7fc2dde6443f3b54aac11eff32623b1ec5f2cf0622c6e2932fdebc255'
